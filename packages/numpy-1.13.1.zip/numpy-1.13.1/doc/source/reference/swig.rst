**************
NumPy and SWIG
**************

.. sectionauthor:: Bill Spotz


.. toctree::
   :maxdepth: 2

   swig.interface-file
   swig.testing
